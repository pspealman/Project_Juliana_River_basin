Otu_veg <- t(info_data) # Samples become rows and OTUs are columns
pca.spec <- rda(Otu_veg)
groups <- factor(rownames(Otu_veg))
plot(pca.spec)
text(pca.spec, labels=groups)
env_fact <- Environmental_variables[-c(1)]
ef <- envfit(pca.spec, env_fact, permu=999)
ef
plot(ef)