# -*- coding: utf-8 -*-
"""
Created on Sun Mar 10 19:41:02 2024

@author: pspea
"""
import numpy as np
import plotly.io as pio
pio.renderers.default = "browser"

import pandas as pd

import plotly.express as px

genus_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/genus_table.tsv')
genus_df = pd.read_table(genus_filename, index_col=0)
genus_dict = genus_df.to_dict('index')

sum_by_sample = {}

for taxa in genus_dict:
    
    for site in ['I','S','V']:
        site_total = 0
        
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            if colname in genus_dict[taxa]:
                val = genus_dict[taxa][colname]
                
                if colname not in sum_by_sample:
                    sum_by_sample[colname] = 0

                sum_by_sample[colname] += val 

taxa_to_represent = {}

for taxa in genus_dict:
    
    if taxa not in taxa_to_represent:
        taxa_to_represent[taxa] = {'I':set(),
                         'V':set(),
                         'S':set()}
    
    for site in ['I','S','V']:
        site_total = 0
        
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            if colname in genus_dict[taxa]:
                sample_sum = sum_by_sample[colname]
                
                val = genus_dict[taxa][colname]
                pct_pop = 100*(val/sample_sum)
                                
                if pct_pop >= 0.1: 
                    taxa_to_represent[taxa][site].add(colname)
                    
                site_total += val
                
    if site_total >= 1.0: 
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            taxa_to_represent[taxa][site].add(colname)

stable_set = set()
stable_phyla = set() 
stable_kingdom = set() 
       
for taxa in taxa_to_represent:
    add_to = True
    for site in ['I','S','V']:
        if len(taxa_to_represent[taxa][site]) < 2:
            add_to = False
    
    if add_to:
        stable_set.add(taxa)
        if ';c__' in taxa:
            phylum = taxa.split(';c__')[0]
            
        else:
            phylum = taxa
            
        phylum = phylum.replace(';__','')
        
        if len(phylum) > 0:
            stable_phyla.add(phylum)
            
        if ';p__' in taxa:
            kingdom = taxa.split(';p__')[0]
        else:
            kingdom = taxa
            
        kingdom = kingdom.replace(';__','')
        
        if len(kingdom) > 0:
            stable_kingdom.add(kingdom)
                
        
print(len(stable_set))

stable_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/stable_genus_table_0.1.tsv')

stable_list = list(stable_set)
genus_df['taxa'] = genus_df.index
stable_genus_df = genus_df[genus_df['taxa'].isin(stable_list)]

stable_genus_df.to_csv(stable_filename, sep = '\t')

total_ct_per_site = {'I':0,
                     'S':0,
                     'V':0}

for taxa in genus_dict:
    for site in total_ct_per_site:        
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            if colname in genus_dict[taxa]:
                val = genus_dict[taxa][colname]
                
                total_ct_per_site[site]+=val
            
genus_pct_dict = {}

for taxa in stable_set:
    rtaxa = taxa.replace(';__','')
    
    if ';' in rtaxa:
        if ';g__' in rtaxa:
            genus = rtaxa.split(';g__')[1]
            phylum = rtaxa.split(';g__')[0]
                
        else:
            genus = rtaxa.rsplit(';',1)[1]
            phylum = rtaxa.rsplit(';',1)[0]
                
        if genus not in genus_pct_dict:
            genus_pct_dict[genus] = {'I':0,'S':0,'V':0, 'p':phylum}
            
        for site in ['I','S','V']:      
            for rep in range(1,4):
                colname = ('{site}{rep}').format(site = site, rep = rep)
                if colname in genus_dict[taxa]:
                    val = genus_dict[taxa][colname]
                    of_total = total_ct_per_site[site]
                    
                    genus_pct_dict[genus][site]+=(val/of_total)*100
                    
stable_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/stable_genus_table_pct.tsv')
genus_pct_df = pd.DataFrame.from_dict(genus_pct_dict, orient="index")
genus_pct_df.to_csv(stable_filename, sep = '\t')

stable_list = list(stable_set)
genus_df['taxa'] = genus_df.index
                    
new_plot_dict = {}
for taxa in genus_pct_dict:
    min_taxa = 0
    
    for site in ["I","S","V"]:
        val = genus_pct_dict[taxa][site]
        if val >= 1.0:
        
            min_taxa += 1
        
    if min_taxa >= 2:        
        new_plot_dict[taxa] = genus_pct_dict[taxa]

for site in ["I","S","V"]:
    print(site)         
    for taxa in new_plot_dict:
        print(taxa, new_plot_dict[taxa][site])
    
new_plot_dict['val'] = {'p':'val', 'I':9, 'S':9, 'V': 9}
             
for site in ["I","S","V"]:
    plot_df = pd.DataFrame.from_dict(new_plot_dict, orient="index", columns=['p', site])
    plot_df['g'] = plot_df.index
    
    fig = px.bar(plot_df, x="p", y=site, color="g", title=site)
    fig.update_layout(
    autosize=False,
    width=1800,
    height=1800,
)
    fig.show()
    class_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/Figures/{}_stable_genus_barplot_3.svg').format(site)
    fig.write_image(class_filename)
    


        