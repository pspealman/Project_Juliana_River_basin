library(pheatmap) 
library(RColorBrewer)

genus_table <- read.delim("C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/03_10_2024_genus-feature-table.tsv")

genus_table$I1_pct<-log10(genus_table$I1/sum(genus_table$I1))
genus_table$I1_pct <- ifelse(is.finite(genus_table$I1_pct), genus_table$I1_pct, 0)
genus_table$I2_pct<-log10(genus_table$I2/sum(genus_table$I2))
genus_table$I2_pct <- ifelse(is.finite(genus_table$I2_pct), genus_table$I2_pct, 0)
genus_table$I3_pct<-log10(genus_table$I3/sum(genus_table$I3))
genus_table$I3_pct <- ifelse(is.finite(genus_table$I3_pct), genus_table$I3_pct, 0)

genus_table$V1_pct<-log10(genus_table$V1/sum(genus_table$V1))
genus_table$V1_pct <- ifelse(is.finite(genus_table$V1_pct), genus_table$V1_pct, 0)
genus_table$V2_pct<-log10(genus_table$V2/sum(genus_table$V2))
genus_table$V2_pct <- ifelse(is.finite(genus_table$V2_pct), genus_table$V2_pct, 0)

genus_table$S1_pct<-log10(genus_table$S1/sum(genus_table$S1))
genus_table$S1_pct <- ifelse(is.finite(genus_table$S1_pct), genus_table$S1_pct, 0)
genus_table$S2_pct<-log10(genus_table$S2/sum(genus_table$S2))
genus_table$S2_pct <- ifelse(is.finite(genus_table$S2_pct), genus_table$S2_pct, 0)
genus_table$S3_pct<-log10(genus_table$S3/sum(genus_table$S3))
genus_table$S3_pct <- ifelse(is.finite(genus_table$S3_pct), genus_table$S3_pct, 0)

# Load the dataset 
r_data <- genus_table[c("S1_pct","S2_pct", "S3_pct", "V1_pct", "V2_pct", "I1_pct", "I2_pct", "I3_pct")]

#set specific column as row names
rownames(r_data) <- r_data$X

#remove original column from data frame
r_data$X <- NULL

paletteLength <- 100
myColor <- colorRampPalette(c("blue", "red"))(paletteLength)

pdf(file = "C:/Gresham/Project_Osun/Project_Osun_v3/supplemental_figures/taxa_abundance_heatmap_2.pdf", width = 4, height = 6)
pheatmap(r_data, color = myColor)
dev.off()
