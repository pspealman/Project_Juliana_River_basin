# -*- coding: utf-8 -*-
"""
Created on Sun Mar 10 19:41:02 2024

@author: pspea
"""
import numpy as np
import plotly.io as pio
pio.renderers.default = "browser"

import pandas as pd

import plotly.express as px

genus_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/genus_table.tsv')
genus_df = pd.read_table(genus_filename, index_col=0)
genus_dict = genus_df.to_dict('index')

sum_by_sample = {}

for taxa in genus_dict:
    
    for site in ['I','S','V']:
        site_total = 0
        
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            if colname in genus_dict[taxa]:
                val = genus_dict[taxa][colname]
                
                if colname not in sum_by_sample:
                    sum_by_sample[colname] = 0

                sum_by_sample[colname] += val                

taxa_to_represent = {}

for taxa in genus_dict:
    
    if taxa not in taxa_to_represent:
        taxa_to_represent[taxa] = {'I':[],
                         'V':[],
                         'S':[]}
    
    for site in ['I','S','V']:        
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            if colname in genus_dict[taxa]:
                if colname in sum_by_sample:
                    sample_sum = sum_by_sample[colname]
                    
                    val = genus_dict[taxa][colname]
                    pct_pop = 100*(val/sample_sum)
                    
                    taxa_to_represent[taxa][site].append(pct_pop)

singular_set = set()
singular_phyla = set() 
singular_kingdom = set() 

def identify_singular(taxa_to_represent, taxa):
    #print(taxa)
    add_to_singular = False
    
    temp_dict = {'I':[], 'S':[], 'V':[]}
    
    singular_lowerbound_set = set()
    singular_upperbound_set = set()
    
    for site in temp_dict:
        val = taxa_to_represent[taxa][site]
        #print('val,', val, taxa_to_represent[taxa])
        temp_dict[site] = val
        
    for site in temp_dict:
        site_list = temp_dict[site]
        #print(site_list)
        
        if sum(site_list) >= 0.001: 
            for each in site_list:
                if each >= 0.001: 
                    singular_upperbound_set.add(site)
        
        if np.mean(site_list) >= 0.0001: 
            for each in site_list:
                if each >= 0.0001: 
                    singular_lowerbound_set.add(site)
            
    if len(singular_lowerbound_set) == 1 and len(singular_upperbound_set) == 1:
        add_to_singular = True
        print(taxa, temp_dict)
        
    return(add_to_singular)

def identify_low_count_singular(taxa_to_represent, taxa):
    #print(taxa)
    add_to_singular = False
    
    temp_dict = {'I':[], 'S':[], 'V':[]}
    
    # singular_lowerbound_set = set()
    # singular_upperbound_set = set()
    
    for site in temp_dict:
        val = taxa_to_represent[taxa][site]
        #print('val,', val, taxa_to_represent[taxa])
        temp_dict[site] = val
        
    temp_site_count = {'I':0, 'S':0, 'V':0}
    for site in temp_dict:
        site_list = temp_dict[site]
        #print(site_list)
        
        # if sum(site_list) > 0: 
        #     for each in site_list:
        #         if each >= 0.0001: 
        #             temp_site_count[site] += 1
        for each in site_list:
            if each >= 0.001: 
                temp_site_count[site] += 1
            
    subset = set()
    xyz = {0:0, 1:0, 2:0, 3:0}
    
    for site in temp_site_count:
        ct = temp_site_count[site]
        xyz[ct] += 1
    
    if (xyz[3] == 1) and (xyz[2] == 0) and (xyz[1] == 0):
            subset.add('triplicate')
    
    if (xyz[3] == 0) and (xyz[2] == 1) and (xyz[1] == 0):
            subset.add('duplicate')
        
    if len(subset) == 1:
        add_to_singular = True
        print(subset)
        print(taxa, taxa_to_represent[taxa])
        
    return(add_to_singular)
            
       
# for taxa in taxa_to_represent:    
#     add_to_singular = identify_singular(taxa_to_represent, taxa)
    
#     if add_to_singular:
#         singular_set.add(taxa)
        
#         if ';c__' in taxa:
#             phylum = taxa.split(';c__')[0]
            
#         else:
#             phylum = taxa
            
#         phylum = phylum.replace(';__','')
        
#         if len(phylum) > 0:
#             singular_phyla.add(phylum)
            
#         if ';p__' in taxa:
#             kingdom = taxa.split(';p__')[0]
#         else:
#             kingdom = taxa
            
#         kingdom = kingdom.replace(';__','')
        
#         if len(kingdom) > 0:
#             singular_kingdom.add(kingdom)
                
        
# print(len(singular_set))
# print(len(singular_phyla))

for taxa in taxa_to_represent:    
    add_to_singular = identify_low_count_singular(taxa_to_represent, taxa)
    
    if add_to_singular:
        singular_set.add(taxa)
        
        if ';c__' in taxa:
            phylum = taxa.split(';c__')[0]
            
        else:
            phylum = taxa
            
        phylum = phylum.replace(';__','')
        
        if len(phylum) > 0:
            singular_phyla.add(phylum)
            
        if ';p__' in taxa:
            kingdom = taxa.split(';p__')[0]
        else:
            kingdom = taxa
            
        kingdom = kingdom.replace(';__','')
        
        if len(kingdom) > 0:
            singular_kingdom.add(kingdom)
                
        
print(len(singular_set))
print(len(singular_phyla))

singular_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/singular_genus_table.tsv')
singular_file = open(singular_filename, 'w')

header = ('taxa\tmean_Impacted\tmean_Source\tmean_Valley\n')
singular_file.write(header)

pct_pop_dict = {'I':0, 'S': 0, 'V': 0}
ct_pop_dict = {'I':0, 'S': 0, 'V': 0}

for taxa in singular_set:
    if taxa in taxa_to_represent:
        for site in taxa_to_represent[taxa]:
            
            pct_pop_dict[site] += np.mean(taxa_to_represent[taxa][site])
            
        outline = ('{taxa}\t{i}\t{s}\t{v}\n').format(
            taxa = taxa, 
            i = np.mean(taxa_to_represent[taxa]['I']),
            s = np.mean(taxa_to_represent[taxa]['S']),
            v = np.mean(taxa_to_represent[taxa]['V']),
            )
        
        singular_file.write(outline)
        
singular_file.close()
#
genus_df = pd.read_table(singular_filename, index_col=0)
genus_dict = genus_df.to_dict('index')

pct_pop_dict = {'I':0, 'S': 0, 'V': 0}
ct_pop_dict = {'I':0, 'S': 0, 'V': 0}

phyla_to_represent = {}

for taxa in genus_dict:    
    if ';c__' in taxa:
        phylum = taxa.split(';c__')[0]
        
    else:
        phylum = taxa
        
    phylum = phylum.replace(';__','')
    
    if phylum not in phyla_to_represent:
        phyla_to_represent[phylum] = {'mean_Impacted':0,
                                      'mean_Source':0,
                                      'mean_Valley':0}
        
    for site in ['mean_Impacted','mean_Source','mean_Valley']:
        val = genus_dict[taxa][site]
        phyla_to_represent[phylum][site] += val
        
plot_dict = {}

for phylum in phyla_to_represent:
    for site in phyla_to_represent[phylum]:
        val = phyla_to_represent[phylum][site]
        if val >= 0.05:
            if phylum not in plot_dict:
                plot_dict[phylum] = {'mean_Impacted': phyla_to_represent[phylum]['mean_Impacted'],
                                     'mean_Source': phyla_to_represent[phylum]['mean_Source'],
                                     'mean_Valley': phyla_to_represent[phylum]['mean_Valley']}
        
plot_dict['val'] = {'mean_Impacted': 0.55,
                     'mean_Source': 0.55,
                     'mean_Valley': 0.55}

for site in ['mean_Impacted', 'mean_Source', 'mean_Valley']:         
    plot_df = pd.DataFrame.from_dict(plot_dict, orient="index", columns = [site])
    plot_df['taxa'] = plot_df.index
    
    fig = px.bar(plot_df, y=site, x='taxa', color='taxa', title=site)
    fig.show()
    class_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/Figures/{}_singular_barplot.svg').format(site)
    fig.write_image(class_filename)
        