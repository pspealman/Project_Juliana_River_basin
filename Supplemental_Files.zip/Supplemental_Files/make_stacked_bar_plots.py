# -*- coding: utf-8 -*-
"""
Created on Sun Mar 10 14:53:04 2024

@author: pspea
"""
import plotly.io as pio
pio.renderers.default = "browser"

import pandas as pd

import plotly.express as px

class_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/class_table.tsv')
class_df = pd.read_table(class_filename, index_col=0)
class_dict = class_df.to_dict('index')

site_dict = {}

total_per_site = {'I':0, 'S':0, 'V':0}

for taxa in class_dict:
    for site in ['I','S','V']:
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            if colname in class_dict[taxa]:
                val = class_dict[taxa][colname]
                total_per_site[site] += val
                
phyla_dict = {}
                
for taxa in class_dict:
    if ';c__' in taxa:
        phyla = taxa.split(';c__')[0]
    else:
        phyla = taxa.replace(';__','')
    
    if phyla not in phyla_dict:
        phyla_dict[phyla] = {'I':0, 'S':0, 'V':0, 'total':0}
    
    for site in ['I','S','V']:
        for rep in range(1,4):
            colname = ('{site}{rep}').format(site = site, rep = rep)
            
            if colname in class_dict[taxa]:
                ct = class_dict[taxa][colname]
                phyla_dict[phyla][site] += ct
                phyla_dict[phyla]['total'] += ct
    else:
        phyla = taxa.replace(';__','')
        
        if phyla not in phyla_dict:
            phyla_dict[phyla] = {'I':0, 'S':0, 'V':0, 'total':0}
        
        for site in ['I','S','V']:
            for rep in range(1,4):
                colname = ('{site}{rep}').format(site = site, rep = rep)
                
                if colname in class_dict[taxa]:
                    ct = class_dict[taxa][colname]
                    phyla_dict[phyla][site] += ct
                    phyla_dict[phyla]['total'] += ct
            
            
sub_phyla = set()

for phyla in phyla_dict:
    for site in ['I', 'S', 'V']:
        total_ct = total_per_site[site]
        taxa_pct = phyla_dict[phyla]['total']/total_ct
    
        if taxa_pct >= 0.01:
            sub_phyla.add(phyla)
        
plot_dict = {}

for site in ['I','S','V']:
    total_ct = total_per_site[site]
    
    for taxa in class_dict:
        if ';c__' in taxa:
            phyla = taxa.split(';c__')[0]
            taxa_class = taxa.split(';c__')[1].split(';')[0]
            
        else:
            phyla = taxa.replace(';__','')
            taxa_class = 'NA'
            
        if phyla in sub_phyla:
            if taxa not in plot_dict:
                plot_dict[taxa] = {'p':phyla, 'c':taxa_class,
                                   'I':0, 'S':0, 'V': 0}
            
            for rep in range(1,4):
                colname = ('{site}{rep}').format(site = site, rep = rep)
                
                if colname in class_dict[taxa]:
                    val = class_dict[taxa][colname]/total_ct
                    plot_dict[taxa][site] += val
                        

plot_dict['val'] = {'p':'val', 'c':'val',
                    'I':0.2, 'S':0.2, 'V': 0.2}
                        

keep_class_set = set()
for taxa in plot_dict:
    for site in ["I","S","V"]:
        if plot_dict[taxa][site] >= 0.02:
            taxa_class = plot_dict[taxa]['c']
            
            keep_class_set.add(taxa)


new_plot_dict = {}

for taxa in plot_dict:
    if taxa in keep_class_set:
            new_plot_dict[taxa] = plot_dict[taxa]

for site in ["I","S","V"]:
    print(site)         
    for taxa in new_plot_dict:
        print(taxa, new_plot_dict[taxa][site])
    
             
for site in ["I","S","V"]:         
    plot_df = pd.DataFrame.from_dict(new_plot_dict, orient="index", columns=['p','c', site])
    
    fig = px.bar(plot_df, x="p", y=site, color="c", title=site)
    fig.update_layout(
    autosize=False,
    width=800,
    height=800,
)
    fig.show()
    #class_filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/Figures/{}_raw_barplot_2.svg').format(site)
    #fig.write_image(class_filename)
    
                        
            
                    
                

        
        
    