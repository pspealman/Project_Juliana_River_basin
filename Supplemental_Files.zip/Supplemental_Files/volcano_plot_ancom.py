# -*- coding: utf-8 -*-
"""
Created on Fri Jan 26 12:51:35 2024

@author: pspea
"""
import pandas as pd
import numpy as np


import plotly.io as pio
pio.renderers.default = "browser"

import plotly.express as px

lookup_dict = {'Spring_Valley': 'Spring_Valley',
               'Mangrove_Spring': 'Mangrove_Spring',
               'Mangrove_Valley': 'Mangrove_Valley'}

for comparison in set(['Spring_Valley', 'Mangrove_Valley', 'Mangrove_Spring']):
    filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/'
                'ancom_{comparison}_lfc_slice.csv').format(
        comparison = comparison)
    
    df = pd.read_csv(filename, sep=',', index_col=0)
    lfc_df = df.drop(columns=['(Intercept)'])
    
    
    filename = ('C:/Gresham/Project_Osun/Project_Osun_v3/qiime_results/'
                'ancom_{comparison}_q_val_slice.csv').format(
        comparison = comparison)
    
    df = pd.read_csv(filename, sep=',', index_col=0)
    q_val_df = df.drop(columns=['(Intercept)'])
    
    qval_column_name = comparison + '_qval'
    lfc_column_name = comparison + '_lfc'
    
    #q_val_df = q_val_df[q_val_df[qval_column_name]<0.01]
    
    plot_df = pd.merge(left = lfc_df,
                               right = q_val_df,
                               left_index=True,
                               right_index=True)



    
    plot_df["nlog10p"] = q_val_df[qval_column_name].apply(lambda x: -1*np.log10(x))
    plot_df['taxa'] = list(q_val_df.index)
    
    conditions = [
        (plot_df[qval_column_name] > 0.05),
        (plot_df[qval_column_name] <= 0.05)
    ]
    
    values = ['qval > 0.05', 'qval <= 0.05']
    
    plot_df['color'] = np.select(conditions, values)
    
    fig = px.scatter(plot_df, x=lfc_column_name, y="nlog10p", color='color', hover_data=['taxa'], render_mode = 'svg')
    
    plot_title = (comparison)
    fig.update_layout(
        title=plot_title,
        xaxis_title="log2FC",
        yaxis_title="-1log10(q-value)",
        font=dict(
            size=18,
            color="Black"
        )
    )
    
    fig.show()

    output_figure_name = ('C:/Gresham/Project_Osun/Project_Osun_v3/Figures/'
                          'ANCOM-BC_{comparison}_genus_volcano.svg').format(
                              comparison = comparison)
    fig.write_image(output_figure_name)
        
    # output_figure_name = ('C:/Gresham/Project_Osun/Project_Osun_v3/Figures/DESeq_Impacted_v_Spring_genus_volcano.png')
    # fig.write_image(output_figure_name)
