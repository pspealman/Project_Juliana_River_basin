###Author Spealman P. 2024
module load r/intel/4.0.4
if (!requireNamespace("BiocManager", quietly=TRUE))
    install.packages("BiocManager")
BiocManager::install("ANCOMBC")
install.packages('tidyverse')

# # Script Section
	# #
	# #Define directory
	base_dir=/scratch/ps163/Project_Osun/
	mapping_file=${base_dir}/metadata/MappingFile_Osun.tsv
	fastq_dir=${base_dir}/fastq/
	qiime_results=${base_dir}/qiime_results/
	mkdir -p ${qiime_results}
	
wget https://data.qiime2.org/2024.2/common/silva-138-99-515-806-nb-classifier.qza


# Retrieve seqeunces:
# 16S_Human_Impacted_Mangrove_Sediment_rep3
fasterq-dump SRR12400118 -o fastq/I3.fastq
fasterq-dump SRR12400119 -o fastq/I2.fastq
fasterq-dump SRR12400120 -o fastq/I1.fastq
#
fasterq-dump SRR12400123 -o fastq/S3.fastq
fasterq-dump SRR12400124 -o fastq/S2.fastq
fasterq-dump SRR12400125 -o fastq/S1.fastq
#
fasterq-dump SRR12400121 -o fastq/V2.fastq
fasterq-dump SRR12400122 -o fastq/V1.fastq

mv fastq/I3_1.fastq fastq/I3_118_L118_R1_001.fastq
mv fastq/I3_2.fastq fastq/I3_118_L118_R2_001.fastq
mv fastq/I2_1.fastq fastq/I2_119_L119_R1_001.fastq
mv fastq/I2_2.fastq fastq/I2_119_L119_R2_001.fastq
mv fastq/I1_1.fastq fastq/I1_120_L120_R1_001.fastq
mv fastq/I1_2.fastq fastq/I1_120_L120_R2_001.fastq
#
mv fastq/S3_1.fastq fastq/S3_123_L123_R1_001.fastq
mv fastq/S3_2.fastq fastq/S3_123_L123_R2_001.fastq
mv fastq/S2_1.fastq fastq/S2_124_L124_R1_001.fastq
mv fastq/S2_2.fastq fastq/S2_124_L124_R2_001.fastq
mv fastq/S1_1.fastq fastq/S1_125_L125_R1_001.fastq
mv fastq/S1_2.fastq fastq/S1_125_L125_R2_001.fastq
#
mv fastq/V2_1.fastq fastq/V2_122_L122_R1_001.fastq
mv fastq/V2_2.fastq fastq/V2_122_L122_R2_001.fastq
mv fastq/V1_1.fastq fastq/V1_121_L121_R1_001.fastq
mv fastq/V1_2.fastq fastq/V1_121_L121_R2_001.fastq
# 


# #
# # #Qiime2 Invocation
	conda activate qiime2-amplicon-2024.2
# #

	# # #
# # # # DADA2 Section
	# # ##########
	# # #/scratch/ps163/Project_Osun/fastq/MSV/casava-18-paired-end-demultiplexed
	# # ##########
	
	qiime tools import \
	  --type 'SampleData[PairedEndSequencesWithQuality]' \
	  --input-path fastq/ \
	  --input-format CasavaOneEightSingleLanePerSampleDirFmt \
	  --output-path fastq/demux-paired-end.qza
	
	qiime dada2 denoise-paired \
	  --i-demultiplexed-seqs fastq/demux-paired-end.qza \
	  --p-trim-left-f 13 \
	  --p-trim-left-r 13 \
	  --p-trunc-len-f 150 \
	  --p-trunc-len-r 150 \
	  --o-table fastq/table-dada2.qza \
	  --o-representative-sequences fastq/rep-seqs-dada2.qza \
	  --o-denoising-stats fastq/denoising-stats.qza
	  
	qiime metadata tabulate \
	--m-input-file fastq/denoising-stats.qza \
	--o-visualization fastq/denoising-stats.qzv
	
	mv fastq/*.qza ${qiime_results}/.
	mv fastq/*.qzv ${qiime_results}/.
	
	# # #v_2:Phylogeny
	qiime phylogeny align-to-tree-mafft-fasttree \
	  --i-sequences ${qiime_results}/rep-seqs-dada2.qza \
	  --o-alignment  ${qiime_results}/aligned-rep-seqs.qza \
	  --o-masked-alignment  ${qiime_results}/masked-aligned-rep-seqs.qza \
	  --o-tree  ${qiime_results}/unrooted-tree.qza \
	  --o-rooted-tree  ${qiime_results}/rooted-tree.qza
	
	# # #v_2:to view trees 
	qiime tools export \
	  --input-path ${qiime_results}/unrooted-tree.qza \
	  --output-path ${qiime_results}/exported-unrooted-tree
	  
	# #v_2:to view trees 
	qiime tools export \
	  --input-path ${qiime_results}/rooted-tree.qza \
	  --output-path ${qiime_results}/exported-rooted-tree
	  
	qiime feature-table summarize \
	  --i-table ${qiime_results}/table-dada2.qza \
	  --o-visualization ${qiime_results}/table-dada2.qzv \
	  --m-sample-metadata-file ${mapping_file}

	qiime feature-table tabulate-seqs \
	  --i-data ${qiime_results}/rep-seqs-dada2.qza \
	  --o-visualization ${qiime_results}/rep-seqs.qzv

	# # # ##  
	# # # Stop here -
	# # # 1. Check min_depth and max_depth
		# # # from ${qiime_results}/table-dada2.qzv 
	# # # 2. Using 41000 as minimum:
		# # # Retained 104,000 (15.80%) features in 8 (100.00%) samples at the specifed sampling depth.
	# # # 3. edit variables below
	# # # ##
	# # # Alpha - beta section
	# # # Alpha raref.
	# # # reapeated for 20K, 40K, and 10K for resolution of lower abundant samples
	max_depth=147000
	qiime diversity alpha-rarefaction \
	  --i-table ${qiime_results}/table-dada2.qza \
	  --i-phylogeny ${qiime_results}/rooted-tree.qza \
	  --p-max-depth ${max_depth} \
	  --m-metadata-file ${mapping_file} \
	  --o-visualization ${qiime_results}/alpha-rarefaction_147K.qzv
	  
	max_depth=50000
	qiime diversity alpha-rarefaction \
	  --i-table ${qiime_results}/table-dada2.qza \
	  --i-phylogeny ${qiime_results}/rooted-tree.qza \
	  --p-max-depth ${max_depth} \
	  --m-metadata-file ${mapping_file} \
	  --o-visualization ${qiime_results}/alpha-rarefaction_50K.qzv
	  
	max_depth=41000
	qiime diversity alpha-rarefaction \
	  --i-table ${qiime_results}/table-dada2.qza \
	  --i-phylogeny ${qiime_results}/rooted-tree.qza \
	  --p-max-depth ${max_depth} \
	  --m-metadata-file ${mapping_file} \
	  --o-visualization ${qiime_results}/alpha-rarefaction_41K.qzv
	
	# #core diversities
	# #double check sampling depth
	min_depth=41000
	core_metrics_results=${qiime_results}/core-metrics-results_5K/
	rm -rf ${core_metrics_results}
		qiime diversity core-metrics-phylogenetic \
		  --i-phylogeny ${qiime_results}/rooted-tree.qza \
		  --i-table ${qiime_results}/table-dada2.qza \
		  --p-sampling-depth ${min_depth} \
		  --m-metadata-file ${mapping_file} \
		  --output-dir ${core_metrics_results}
		  
		#double check sampling depth
		
		qiime diversity alpha-group-significance \
		  --i-alpha-diversity ${core_metrics_results}/observed_features_vector.qza \
		  --m-metadata-file ${mapping_file} \
		  --o-visualization ${core_metrics_results}/observed-water-group-significance.qzv
		
		qiime diversity alpha-group-significance \
		  --i-alpha-diversity ${core_metrics_results}/faith_pd_vector.qza \
		  --m-metadata-file ${mapping_file} \
		  --o-visualization ${core_metrics_results}/faith-pd-group-significance.qzv
		
		qiime diversity alpha-group-significance \
		  --i-alpha-diversity ${core_metrics_results}/shannon_vector.qza \
		  --m-metadata-file ${mapping_file} \
		  --o-visualization ${core_metrics_results}/shannon-group-significance.qzv
		 
		 qiime diversity alpha-group-significance \
		  --i-alpha-diversity ${core_metrics_results}/evenness_vector.qza \
		  --m-metadata-file ${mapping_file} \
		  --o-visualization ${core_metrics_results}/evenness-group-significance.qzv
		
		qiime diversity beta-group-significance \
		  --i-distance-matrix ${core_metrics_results}/weighted_unifrac_distance_matrix.qza \
		  --m-metadata-file ${mapping_file} \
		  --m-metadata-column Site \
		  --o-visualization ${core_metrics_results}/weighted-unifrac-site-significance.qzv \
		  --p-pairwise
		  
		qiime diversity beta-group-significance \
		  --i-distance-matrix  ${core_metrics_results}/bray_curtis_distance_matrix.qza \
		  --m-metadata-file ${mapping_file} \
		  --m-metadata-column Site \
		  --o-visualization ${core_metrics_results}/bray_curtis-site-significance.qzv \
		  --p-pairwise
		  
		qiime diversity beta-group-significance \
		  --i-distance-matrix  ${core_metrics_results}/jaccard_distance_matrix.qza \
		  --m-metadata-file ${mapping_file} \
		  --m-metadata-column Site \
		  --o-visualization ${core_metrics_results}/jaccard_site-significance.qzv \
		  --p-pairwise
		  
		qiime diversity beta-group-significance \
		  --i-distance-matrix  ${core_metrics_results}/jaccard_distance_matrix.qza \
		  --m-metadata-file ${mapping_file} \
		  --m-metadata-column Site \
		  --o-visualization ${core_metrics_results}/jaccard_site-significance.qzv \
		  --p-pairwise
		  
		qiime diversity beta-group-significance \
		  --i-distance-matrix  ${core_metrics_results}/unweighted_unifrac_distance_matrix.qza \
		  --m-metadata-file ${mapping_file} \
		  --m-metadata-column Site \
		  --o-visualization ${core_metrics_results}/unweighted-unifrac-site-significance.qzv \
		  --p-pairwise
# # #
# # # ##
	# #taxonomy
	qiime feature-classifier classify-sklearn \
	  --i-classifier ${base_dir}/metadata/silva-138-99-515-806-nb-classifier.qza \
	  --i-reads ${qiime_results}/rep-seqs-dada2.qza \
	  --o-classification ${qiime_results}/taxonomy.qza
	 
	qiime metadata tabulate \
	  --m-input-file ${qiime_results}/taxonomy.qza \
	  --o-visualization ${qiime_results}/taxonomy.qzv
	  
	qiime taxa barplot \
	  --i-table ${qiime_results}/table-dada2.qza \
	  --i-taxonomy ${qiime_results}/taxonomy.qza \
	  --m-metadata-file ${mapping_file} \
	  --o-visualization ${qiime_results}/taxa-bar-plots.qzv

# # ### for genus level
# levelname=species
# level=7
levelname=genus
level=6
# levelname=family
# level=5
# levelname=order
# level=4
# levelname=class
# level=3
# levelname=phyla
# level=2
# levelname=kingdom
# level=1

qiime taxa collapse \
  --i-table ${qiime_results}/table-dada2.qza \
  --i-taxonomy ${qiime_results}/taxonomy.qza \
  --p-level ${level} \
  --o-collapsed-table ${qiime_results}/collapsed-${levelname}-table.qza
  
	mkdir -p extracted-feature-table-${levelname}
	qiime tools extract \
	  --input-path ${qiime_results}/collapsed-${levelname}-table.qza \
	  --output-path ${qiime_results}/extracted-feature-table-${levelname}
	 
	qiime tools export \
	--input-path ${qiime_results}/collapsed-${levelname}-table.qza \
	--output-path ${qiime_results}/extracted-feature-table-${levelname}
	
	biom convert -i ${qiime_results}/extracted-feature-table-${levelname}/feature-table.biom -o ${qiime_results}/${levelname}_table.tsv --to-tsv

	qiime taxa barplot \
	  --i-table ${qiime_results}/collapsed-genus-table.qza \
	  --i-taxonomy ${qiime_results}/taxonomy.qza \
	  --m-metadata-file ${mapping_file} \
	  --o-visualization ${qiime_results}/collapsed_genus-taxa-bar-plots.qzv
	
	mkdir extracted-feature-table
	qiime tools extract \
	  --input-path ${qiime_results}/collapsed-genus-table.qza \ \
	  --output-path ${qiime_results}/extracted-feature-table
	 
	qiime tools export \
	--input-path ${qiime_results}/collapsed-genus-table.qza \
	--output-path ${qiime_results}/extracted-feature-table
#
# ANCOM-BC for differential analysis
	# #taxonomy
	typeis1=Spring
	typeis2=Valley
		qiime feature-table filter-samples \
		  --i-table ${qiime_results}/table-dada2.qza \
		  --m-metadata-file ${mapping_file} \
		  --p-where "([Site]='${typeis1}') OR ([Site]='${typeis2}')" \
		  --o-filtered-table ${qiime_results}/out.qza
		#
		qiime feature-table summarize\
		  --i-table ${qiime_results}/out.qza \
		  --m-sample-metadata-file ${mapping_file} \
		  --o-visualization ${qiime_results}/out.qzv
		#
		qiime taxa collapse \
		--i-table ${qiime_results}/out.qza \
		--i-taxonomy ${qiime_results}/taxonomy.qza \
		--p-level 6 \
		--o-collapsed-table ${qiime_results}/out_collapsed-genus-table.qza
		#
		qiime composition ancombc \
		--i-table ${qiime_results}/out_collapsed-genus-table.qza \
		--m-metadata-file ${mapping_file} \
		--p-p-adj-method 'fdr' \
		--p-formula Site \
		--o-differentials ${qiime_results}/ancom_bc_${typeis1}_${typeis2}.qza
		echo ${qiime_results}/ancom_bc_${typeis1}_${typeis2}.qza
		
	# #taxonomy
	typeis1=Valley
	typeis2=Mangrove
		qiime feature-table filter-samples \
		  --i-table ${qiime_results}/table-dada2.qza \
		  --m-metadata-file ${mapping_file} \
		  --p-where "([Site]='${typeis1}') OR ([Site]='${typeis2}')" \
		  --o-filtered-table ${qiime_results}/out.qza
		#
		qiime feature-table summarize\
		  --i-table ${qiime_results}/out.qza \
		  --m-sample-metadata-file ${mapping_file} \
		  --o-visualization ${qiime_results}/out.qzv
		#
		qiime taxa collapse \
		--i-table ${qiime_results}/out.qza \
		--i-taxonomy ${qiime_results}/taxonomy.qza \
		--p-level 6 \
		--o-collapsed-table ${qiime_results}/out_collapsed-genus-table.qza
		#
		qiime composition ancombc \
		--i-table ${qiime_results}/out_collapsed-genus-table.qza \
		--m-metadata-file ${mapping_file} \
		--p-p-adj-method 'fdr' \
		--p-formula Site \
		--o-differentials ${qiime_results}/ancom_bc_${typeis1}_${typeis2}.qza
		
		
	# #taxonomy
	typeis1=Spring
	typeis2=Mangrove
		qiime feature-table filter-samples \
		  --i-table ${qiime_results}/table-dada2.qza \
		  --m-metadata-file ${mapping_file} \
		  --p-where "([Site]='${typeis1}') OR ([Site]='${typeis2}')" \
		  --o-filtered-table ${qiime_results}/out.qza
		#
		qiime feature-table summarize\
		  --i-table ${qiime_results}/out.qza \
		  --m-sample-metadata-file ${mapping_file} \
		  --o-visualization ${qiime_results}/out.qzv
		#
		qiime taxa collapse \
		--i-table ${qiime_results}/out.qza \
		--i-taxonomy ${qiime_results}/taxonomy.qza \
		--p-level 6 \
		--o-collapsed-table ${qiime_results}/out_collapsed-genus-table.qza
		#
		qiime composition ancombc \
		--i-table ${qiime_results}/out_collapsed-genus-table.qza \
		--m-metadata-file ${mapping_file} \
		--p-p-adj-method 'fdr' \
		--p-formula Site \
		--o-differentials ${qiime_results}/ancom_bc_${typeis1}_${typeis2}.qza
		
		
	# #picrost
	# qiime picrust2 full-pipeline \
		# --i-table ${qiime_results}table-dada2.qza \
		# --i-seq ${qiime_results}rep-seqs-dada2.qza \
		# --output-dir ${qiime_results}q2-picrust2_output \
		# --verbose