require(phyloseq)
SED_process = filter_taxa(SEDIM, function(x) sum(x > 3) > (0.2*length(x)), TRUE)
SED_process
#Create ordination object and plot NMDS and PCoAs
Ordination <-ordinate(SED_process, "NMDS", "bray")
Ordination
Ord_plot <- plot_ordination(SED_process, Ordination,  type= "samples", shape= "Site", color = "Site", title="Taxa Ordination Bray-Curtis")+ geom_point(size=5)
Ord_plot

